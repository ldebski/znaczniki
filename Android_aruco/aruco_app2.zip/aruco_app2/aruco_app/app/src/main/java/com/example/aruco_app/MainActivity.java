package com.example.aruco_app;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

import org.opencv.android.OpenCVLoader;
import org.opencv.android.Utils;
import org.opencv.core.Mat;
import org.opencv.aruco.*;


import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.LinkedList;
import java.util.List;

import static org.opencv.imgproc.Imgproc.cvtColor;


public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);

        if (!OpenCVLoader.initDebug())
            Log.e("OpenCv", "Unable to load OpenCV");
        else {
            Log.d("OpenCv", "OpenCV loaded");

            //read image
            InputStream stream = null;
            Uri uri = Uri.parse("android.resource://"+getApplicationContext().getPackageName()+"/"+R.drawable.camera1);
            try {
                stream = getContentResolver().openInputStream(uri);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }

            BitmapFactory.Options bmpFactoryOptions = new BitmapFactory.Options();
            bmpFactoryOptions.inPreferredConfig = Bitmap.Config.ARGB_8888;

            Bitmap bmp = BitmapFactory.decodeStream(stream, null, bmpFactoryOptions);
            Mat image = new Mat();
            Utils.bitmapToMat(bmp, image);
            //to black and white
            cvtColor(image, image, 10);
            Log.e("IMG",image.width()+"");

            Dictionary dictionary=Aruco.getPredefinedDictionary(Aruco.DICT_4X4_250);
            List<Mat> corners=new LinkedList<>();
            Mat ids;
            DetectorParameters parameters=DetectorParameters.create();
            for(int i=0;i<20;i++) {
                ids = new Mat();
                corners.clear();

                //detecting
                if(!image.empty()) {
                    long startTime = System.currentTimeMillis();
                    Aruco.detectMarkers(image, dictionary, corners, ids, parameters);
                    long estimatedTime = System.currentTimeMillis() - startTime;
                    Log.e("time milliseconds",estimatedTime+"");
                    if(!ids.empty()){
                       Log.e("Success","success");
                   }
                }
            }

        }

        setContentView(R.layout.activity_main);
    }
}